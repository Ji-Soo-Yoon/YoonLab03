package edu.westga.comp2320.grocery.model;

import java.util.ArrayList;

/**
 * This class represent a grocery list that stores items.
 * Provides functionality to add items and display the list as a string.
 * 
 * @author Jisoo Yoon
 * @version 1/27/2024
 */
public class GroceryList {
	private ArrayList<String> list;
	
	/**
     * This method creates a new GroceryList with an empty list of items.
     */
	public GroceryList() {
		this.list = new ArrayList<>();
	}
	
	/**
     * Adds an item to the grocery list.
     *
     * @param item to add to the list
     * @throws IllegalArgumentException if the item is null or empty
     */
	public void addItem(String item) {
		if (item == null || item.trim().isEmpty()) {
			throw new IllegalArgumentException("Item can't be null or empty");
		}
		this.list.add(item);
	}
	
	/**
     * Returns a string representation of the grocery list.
     * Each item is displayed on its own line.
     *
     * @return the string representation of the list
     */
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder("The list contains:\n");
		for (String item: this.list) {
			result.append(item).append("\n");
		}
		return result.toString();
	}
}
