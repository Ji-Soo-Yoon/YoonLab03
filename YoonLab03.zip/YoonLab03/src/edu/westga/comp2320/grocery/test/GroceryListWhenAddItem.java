package edu.westga.comp2320.grocery.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.westga.comp2320.grocery.model.GroceryList;

/**
 * JUnit tests for the GroceryList class.
 * Verifies the behavior of the addItem method and toString method.
 * 
 * @author Jisoo Yoon
 * @version 1/27/2024
 */
public class GroceryListWhenAddItem {

    private GroceryList groceryList;

    /**
     * Initializes a new GroceryList instance before each test.
     */
    @BeforeEach
    public void setUp() {
        this.groceryList = new GroceryList();
    }

    /**
     * Tests the toString method for an empty grocery list.
     */
    @Test
    public void testToStringOnEmptyList() {
        assertEquals("The list contains:\n", this.groceryList.toString());
    }

    /**
     * Tests adding a single item to the grocery list.
     */
    @Test
    public void testAddOneItem() {
        this.groceryList.addItem("Apples");
        assertEquals("The list contains:\nApples\n", this.groceryList.toString());
    }

    /**
     * Tests adding multiple items to the grocery list.
     */
    @Test
    public void testAddMultipleItems() {
        this.groceryList.addItem("Apples");
        this.groceryList.addItem("Bananas");
        this.groceryList.addItem("Carrots");
        assertEquals("The list contains:\nApples\nBananas\nCarrots\n", this.groceryList.toString());
    }

    /**
     * Tests that adding a null item throws an exception.
     */
    @Test
    public void testAddNullItemThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> this.groceryList.addItem(null));
    }

    /**
     * Tests that adding an empty string throws an exception.
     */
    @Test
    public void testAddEmptyItemThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> this.groceryList.addItem(""));
    }

    /**
     * Tests that adding a whitespace-only string throws an exception.
     */
    @Test
    public void testAddWhitespaceOnlyItemThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> this.groceryList.addItem("   "));
    }
}
